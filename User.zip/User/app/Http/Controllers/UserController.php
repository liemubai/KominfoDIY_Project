<?php

namespace App\Http\Controllers;

use App\Models\User;

//return type View
use Illuminate\View\View;

use Illuminate\Http\Request;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Storage;

class UserController extends Controller
{
    /**
     * index
     *
     * @return View
     */
    public function index(): View
    {
        //get posts
        $posts = User::latest()->paginate(5);

        //render view with posts
        return view('user.index', compact('posts'));
    }

    public function create(): View
    {
        return view('user.create');
    }

    public function store(Request $request): RedirectResponse
    {
        // //validate form
        // $this->validate($request, [
        //     'id'            => 'required|min:1',
        //     'username'      => 'required|min:5',
        //     'email'         => 'required|min:10',
        //     'password'      => 'required|min:5',
        //     'created_at'    => 'required|min:5',
        //     'updated_at'    => 'required|min:5'
        // ]);

        //create post
        Post::create([
            'id'            => $request->id,
            'username'      => $request->username,
            'email'         => $request->email,
            'password'      => $request->password,
            'created_at'    => $request->created_at,
            'updated_at'    => $request->updated_at
        ]);

        //redirect to index
        return redirect()->route('user.index');
    }

    public function show(string $id): View
    {
        //get post by ID
        $post = User::findOrFail($id);

        //render view with post
        return view('user.show', compact('post'));
    }

    public function edit(string $id): View
    {
        //get post by ID
        $post = User::findOrFail($id);

        //render view with post
        return view('user.edit', compact('post'));
    }
    
    /**
     * update
     *
     * @param  mixed $request
     * @param  mixed $id
     * @return RedirectResponse
     */
    public function update(Request $request, $id): RedirectResponse
    {
        //validate form
        $this->validate($request, [
            'id'     => 'required|min:1',
            'username'     => 'required|min:5',
            'email'   => 'required|min:10',
            'password'   => 'required|min:10',
            'created_at'   => 'required|min:10',
            'updated_at'   => 'required|min:10'
        ]);

        //get post by ID
        $post = User::findOrFail($id);

        $post->update([
            'id'     => $request->id,
            'username'   => $request->username,
            'email'     => $request->email,
            'password'     => $request->password,
            'created_at'     => $request->created_at,
            'updated_at'     => $request->updated_at,
        ]);

        

        //redirect to index
        return redirect()->route('user.index')->with(['success' => 'Data Berhasil Diubah!']);
    }


    public function destroy($id): RedirectResponse
    {
        //get post by ID
        $post = User::findOrFail($id);

        //delete post
        $post->delete();

        //redirect to index
        return redirect()->route('user.index')->with(['success' => 'Data Berhasil Dihapus!']);
    }



}
